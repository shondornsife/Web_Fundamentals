function removeMe(buttonElement) {
    buttonElement.remove();
}
function switchButton() {
    loginButton.innerText = "Logout";
}