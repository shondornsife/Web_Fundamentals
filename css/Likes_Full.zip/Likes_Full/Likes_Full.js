function add1(addId) {
    document.querySelector(addId).innerText++;
}